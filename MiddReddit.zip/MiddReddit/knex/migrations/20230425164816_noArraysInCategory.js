/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
  return knex.schema.table("Category", (table) => {
    table.dropColumn("relatedPosts");
  });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function (knex) {
  return knex.schema.table("Category", (table) => {
    table.specificType("relatedPosts", "INT[]");
  });
};
